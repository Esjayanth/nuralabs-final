<?php
require_once __DIR__ . '/../vendor/autoload.php';

// ============================================================================
// DIRECT DATABASE CONFIGURATION (No .env file needed)
// ============================================================================

// --- MySQL Configuration (InfinityFree) ---
define('DB_HOST', 'sql205.infinityfree.com');
define('DB_PORT', '3306');
define('DB_NAME', 'if0_42710561_nurahub');
define('DB_USER', 'if0_42710561');
define('DB_PASS', '7igD0ACTvi63B');

// --- MongoDB Atlas Configuration ---
define('MONGO_URI', 'mongodb+srv://jbadithya2005_db_user:NuraHub2026Test@cluster0.jxsbeo9.mongodb.net/?appName=Cluster0');
define('MONGO_DB', 'nurahub_auth');

// --- Redis Cloud Configuration ---
define('REDIS_HOST', 'guide-hearty-translucent-91388.db.redis.io');
define('REDIS_PORT', 15590);
define('REDIS_PASS', '@Jaibala7');

// --- Session Constants ---
const SESSION_TTL_SECONDS = 3600;
const SESSION_COOKIE_NAME = 'nh_session';

/**
 * Returns a singleton PDO MySQL instance
 */
function getMysqlConnection(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 5,
        ]);
    }
    return $pdo;
}

/**
 * Returns a MongoDB Collection instance
 */
function getMongoCollection(): ?MongoDB\Collection {
    try {
        if (!class_exists('MongoDB\Client')) {
            return null;
        }

        if (!defined('MONGO_URI') || empty(MONGO_URI)) {
            throw new RuntimeException('MONGO_URI is not defined');
        }

        $client = new MongoDB\Client(MONGO_URI);
        $db = $client->selectDatabase(MONGO_DB);
        return $db->selectCollection('profiles');

    } catch (Throwable $e) {
        error_log('MongoDB connection notice: ' . $e->getMessage());
        return null;
    }
}

/**
 * Returns a Redis instance or null (falls back to native session)
 */
function getRedisConnection(): ?Redis {
    static $redis = null;
    static $attempted = false;
    if ($redis === null && !$attempted) {
        $attempted = true;
        try {
            if (!class_exists('Redis')) {
                return null;
            }
            $candidate = new Redis();
            $candidate->connect(REDIS_HOST, (int) REDIS_PORT, 2);
            if (defined('REDIS_PASS') && REDIS_PASS !== '') {
                $candidate->auth(REDIS_PASS);
            }
            $candidate->ping();
            $redis = $candidate;
        } catch (Throwable $e) {
            error_log('Redis unavailable, using native PHP session fallback: ' . $e->getMessage());
            $redis = null;
        }
    }
    return $redis;
}

/**
 * Helper to output standardized JSON responses and exit
 */
function jsonResponse(bool $ok, string $message = '', array $data = [], int $httpCode = 200): void {
    http_response_code($httpCode);
    header('Content-Type: application/json');
    echo json_encode(array_merge(['ok' => $ok, 'message' => $message], $data));
    exit;
}
